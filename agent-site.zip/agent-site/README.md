# Agent site

Next.js chat site backed by OpenRouter. The API key stays on the server.

## Run locally
1. `npm install`
2. Copy `.env.example` to `.env.local` and set `OPENROUTER_API_KEY`
3. `npm run dev` and open http://localhost:3000

## Customize
Edit `site.config.js` for the agent's name, copy, suggestions and system prompt.
Colors and type live in `app/globals.css` and `app/layout.js`.

## Deploy on Vercel
1. Push this folder to a GitHub repo (`.env.local` is git-ignored).
2. In Vercel: Add New → Project → import the repo.
3. Before deploying, add `OPENROUTER_API_KEY` under Environment Variables.
4. Deploy. Redeploy after changing any environment variable.
