"use client";
import { useState, useRef, useEffect } from "react";
import { agent } from "../site.config";

export default function Home() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const endRef = useRef(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, busy]);

  async function send(text) {
    const content = text.trim();
    if (!content || busy) return;
    const next = [...messages, { role: "user", content }];
    setMessages(next);
    setInput("");
    setError("");
    setBusy(true);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: next }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Request failed.");
      setMessages([...next, { role: "assistant", content: data.reply }]);
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="shell">
      <section className="intro">
        <p className="name">{agent.name}</p>
        <h1>{agent.tagline}</h1>
        <p className="desc">{agent.description}</p>
      </section>

      <section className="chat" aria-label={`Chat with ${agent.name}`}>
        <div className="log" aria-live="polite">
          {messages.length === 0 && (
            <div className="empty">
              <p>Start with a question, or try one of these.</p>
              <div className="chips">
                {agent.suggestions.map((s) => (
                  <button key={s} onClick={() => send(s)}>{s}</button>
                ))}
              </div>
            </div>
          )}
          {messages.map((m, i) => (
            <div key={i} className={`msg ${m.role}`}>{m.content}</div>
          ))}
          {busy && <div className="msg assistant pending">{agent.name} is thinking</div>}
          {error && <div className="error" role="alert">{error}</div>}
          <div ref={endRef} />
        </div>
        <div className="composer">
          <textarea
            rows={1}
            value={input}
            placeholder={agent.placeholder}
            aria-label="Message"
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(input); }
            }}
          />
          <button onClick={() => send(input)} disabled={busy || !input.trim()}>Send</button>
        </div>
      </section>
    </main>
  );
}
