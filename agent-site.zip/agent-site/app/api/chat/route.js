import { agent } from "../../../site.config";

export const maxDuration = 60;

export async function POST(req) {
  const key = process.env.OPENROUTER_API_KEY;
  if (!key) {
    return Response.json(
      { error: "Missing OPENROUTER_API_KEY. Add it in .env.local or in Vercel's environment variables." },
      { status: 500 }
    );
  }

  let body;
  try { body = await req.json(); } catch { return Response.json({ error: "Invalid request." }, { status: 400 }); }

  const history = (Array.isArray(body.messages) ? body.messages : [])
    .filter((m) => (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
    .slice(-20)
    .map((m) => ({ role: m.role, content: m.content.slice(0, 4000) }));
  if (history.length === 0) return Response.json({ error: "No message provided." }, { status: 400 });

  try {
    const r = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: process.env.OPENROUTER_MODEL || "openrouter/free",
        messages: [{ role: "system", content: agent.systemPrompt }, ...history],
      }),
    });
    const data = await r.json();
    if (!r.ok) {
      return Response.json({ error: data?.error?.message || "The model request failed. Try again." }, { status: 502 });
    }
    const reply = data?.choices?.[0]?.message?.content;
    if (!reply) return Response.json({ error: "The model returned an empty reply. Try again." }, { status: 502 });
    return Response.json({ reply });
  } catch {
    return Response.json({ error: "Could not reach OpenRouter. Check your connection and try again." }, { status: 502 });
  }
}
